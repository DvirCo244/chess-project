package com.example.chessgame.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.chessgame.R;
import com.example.chessgame.repository.Repository;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class LoginActivity extends AppCompatActivity {
    private LoginPresenter Presenter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    Presenter = new LoginPresenter(this);
    }

    public String getEmail(){
        EditText email = (EditText) findViewById(R.id.edittext_email);
        return email.getText().toString();
    }

    public String getPassword(){
        EditText password = (EditText) findViewById(R.id.edittext_password);
        return password.getText().toString();
    }

    @Override
    public void onStart() {
        super.onStart();
        Presenter.onStart();
    }

    public void register(View view){
        Presenter.registerClicked();
    }
    public void login(View view){
        Presenter.loginClicked();
    }

    public void navegateToOpenActivity(){
        startActivity(new Intent(LoginActivity.this,OpenActivity.class));
    }
    public void showError(){
        Toast.makeText(this,"error occurred",Toast.LENGTH_SHORT).show();
    }
}