package com.example.chessgame.ui;

import com.example.chessgame.repository.Repository;
import com.google.firebase.database.core.Repo;

public class GamePresenter {
    private GameActivity view;

    public GamePresenter(GameActivity view){
        this.view = view;
    }
    public String getCode(){
      return  Repository.getInstance().getId();
    }
}
