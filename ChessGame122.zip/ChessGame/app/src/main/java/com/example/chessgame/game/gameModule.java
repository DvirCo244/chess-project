package com.example.chessgame.game;

import android.util.Log;

import com.example.chessgame.R;
import com.example.chessgame.pieces.ChessPiece;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class gameModule {
   private static ChessPiece piecesBox[] = {
           new ChessPiece(0, 0, ChessPiece.ChessPlayer.BLACK, ChessPiece.Type.ROOK, R.drawable.blackcastle_new,R.id.black_castle),
           new ChessPiece(0, 1, ChessPiece.ChessPlayer.BLACK, ChessPiece.Type.KNIGHT, R.drawable.blackknight_new,R.id.black_knight),
           new ChessPiece(0, 2, ChessPiece.ChessPlayer.BLACK, ChessPiece.Type.BISHOP, R.drawable.blackbishop_new,R.id.black_bishop),
           new ChessPiece(0, 3, ChessPiece.ChessPlayer.BLACK, ChessPiece.Type.QUEEN, R.drawable.blackqueen_new,R.id.black_queen),
           new ChessPiece(0, 4, ChessPiece.ChessPlayer.BLACK, ChessPiece.Type.KING, R.drawable.blackking_new,R.id.black_king),
           new ChessPiece(0, 5, ChessPiece.ChessPlayer.BLACK, ChessPiece.Type.BISHOP, R.drawable.blackbishop_new,R.id.black_bishop2),
           new ChessPiece(0, 6, ChessPiece.ChessPlayer.BLACK, ChessPiece.Type.KNIGHT, R.drawable.blackknight_new,R.id.black_knight2),
           new ChessPiece(0, 7, ChessPiece.ChessPlayer.BLACK, ChessPiece.Type.ROOK, R.drawable.blackcastle_new,R.id.black_castle2),

           new ChessPiece(7, 0, ChessPiece.ChessPlayer.WHITE, ChessPiece.Type.ROOK, R.drawable.whitecastle_new,R.id.white_castle),
           new ChessPiece(7, 1, ChessPiece.ChessPlayer.WHITE, ChessPiece.Type.KNIGHT, R.drawable.whiteknight_new,R.id.white_knight),
           new ChessPiece(7, 2, ChessPiece.ChessPlayer.WHITE, ChessPiece.Type.BISHOP, R.drawable.whitebishop_new,R.id.white_bishop),
           new ChessPiece(7, 3, ChessPiece.ChessPlayer.WHITE, ChessPiece.Type.QUEEN, R.drawable.whitequeen_new,R.id.white_queen),
           new ChessPiece(7, 4, ChessPiece.ChessPlayer.WHITE, ChessPiece.Type.KING, R.drawable.whiteking_new,R.id.white_king),
           new ChessPiece(7, 5, ChessPiece.ChessPlayer.WHITE, ChessPiece.Type.BISHOP, R.drawable.whitebishop_new,R.id.white_bishop),
           new ChessPiece(7, 6, ChessPiece.ChessPlayer.WHITE, ChessPiece.Type.KNIGHT, R.drawable.whiteknight_new,R.id.white_knight2),
           new ChessPiece(7, 7, ChessPiece.ChessPlayer.WHITE, ChessPiece.Type.ROOK, R.drawable.whitecastle_new,R.id.white_castle2),

           new ChessPiece(1, 0, ChessPiece.ChessPlayer.BLACK, ChessPiece.Type.PAWN, R.drawable.blackpawn_new,R.id.black_pawn0),
           new ChessPiece(1, 7, ChessPiece.ChessPlayer.BLACK, ChessPiece.Type.PAWN, R.drawable.blackpawn_new,R.id.black_pawn7),
           new ChessPiece(1, 6, ChessPiece.ChessPlayer.BLACK, ChessPiece.Type.PAWN, R.drawable.blackpawn_new,R.id.black_pawn6),
           new ChessPiece(1, 5, ChessPiece.ChessPlayer.BLACK, ChessPiece.Type.PAWN, R.drawable.blackpawn_new,R.id.black_pawn5),
           new ChessPiece(1, 4, ChessPiece.ChessPlayer.BLACK, ChessPiece.Type.PAWN, R.drawable.blackpawn_new,R.id.black_pawn4),
           new ChessPiece(1, 3, ChessPiece.ChessPlayer.BLACK, ChessPiece.Type.PAWN, R.drawable.blackpawn_new,R.id.black_pawn3),
           new ChessPiece(1, 2, ChessPiece.ChessPlayer.BLACK, ChessPiece.Type.PAWN, R.drawable.blackpawn_new,R.id.black_pawn2),
           new ChessPiece(1, 1, ChessPiece.ChessPlayer.BLACK, ChessPiece.Type.PAWN, R.drawable.blackpawn_new,R.id.black_pawn1),

           new ChessPiece(6, 0, ChessPiece.ChessPlayer.WHITE, ChessPiece.Type.PAWN, R.drawable.whitepawn_new,R.id.white_pawn0),
           new ChessPiece(6, 1, ChessPiece.ChessPlayer.WHITE, ChessPiece.Type.PAWN, R.drawable.whitepawn_new,R.id.white_pawn1),
           new ChessPiece(6, 2, ChessPiece.ChessPlayer.WHITE, ChessPiece.Type.PAWN, R.drawable.whitepawn_new,R.id.white_pawn2),
           new ChessPiece(6, 3, ChessPiece.ChessPlayer.WHITE, ChessPiece.Type.PAWN, R.drawable.whitepawn_new,R.id.white_pawn3),
           new ChessPiece(6, 4, ChessPiece.ChessPlayer.WHITE, ChessPiece.Type.PAWN, R.drawable.whitepawn_new,R.id.white_pawn4),
           new ChessPiece(6, 5, ChessPiece.ChessPlayer.WHITE, ChessPiece.Type.PAWN, R.drawable.whitepawn_new,R.id.white_pawn5),
           new ChessPiece(6, 6, ChessPiece.ChessPlayer.WHITE, ChessPiece.Type.PAWN, R.drawable.whitepawn_new,R.id.white_pawn6),
           new ChessPiece(6, 7, ChessPiece.ChessPlayer.WHITE, ChessPiece.Type.PAWN, R.drawable.whitepawn_new,R.id.white_pawn7),
    };
   public gameModule(){
   }

   public void removePiece(int fromCol,int fromRow){
       for(int i = 0;i<32;i++)
       {
           if(fromRow == piecesBox[i].getRow() && fromCol == piecesBox[i].getCol())
           {
               piecesBox[i] = null;
           }
       }
   }

   public void movePiece(int fromCol,int toCol,int fromRow,int toRow){
    if(pieceAt(fromCol,fromRow) != null
            && (fromRow >= 0 && fromRow<=7)
            && (fromCol >= 0 && fromCol<=7)
            && (toCol >= 0 && toCol<=7)
            && (toRow >= 0 && toRow<=7)) {
        pieceAt(fromCol, fromRow).setCol(toCol);
        pieceAt(toCol, fromRow).setRow(toRow);
    }
   }

public ChessPiece pieceAt(int i){
    return piecesBox[i];
}

   public ChessPiece pieceAt(int col,int row){
    for(int i = 0;i<32;i++)
    {
        if(row == piecesBox[i].getRow() && col == piecesBox[i].getCol())
            return piecesBox[i];
    }
    return null;
   }


}
