package com.example.chessgame.ui;

import com.example.chessgame.repository.Repository;
import com.google.firebase.database.core.Repo;

import java.util.Random;

public class OpenPresenter {

    private OpenActivity view;

    public OpenPresenter(OpenActivity view) {
        this.view = view;
    }

    public void logout(){
        Repository.getInstance().getAUTH().signOut();
    }

    public boolean createGame(){
        String gameCode;
        Random rand = new Random();
        int lobbyId = rand.nextInt(9999999);
        gameCode = String.format("%06d",lobbyId);
        Repository.getInstance().updateId(gameCode);
            return Repository.getInstance().createGame();
    }

    public boolean joinGame(String gameCode) {
        Repository.getInstance().updateId(gameCode);
        return Repository.getInstance().joinGame();
    }

}
