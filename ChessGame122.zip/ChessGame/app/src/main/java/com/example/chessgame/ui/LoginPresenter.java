package com.example.chessgame.ui;

import com.example.chessgame.repository.Repository;
import com.google.firebase.database.core.Repo;

public class LoginPresenter
{
    private LoginActivity view;
    public LoginPresenter(LoginActivity view)
    {
        this.view = view;
        Repository.getInstance().reset();
    }

    public void registerClicked(){
        String email = view.getEmail();
        String password = view.getPassword();
        if(Repository.getInstance().register(email, password))
            view.navegateToOpenActivity();
        else
            view.showError();
}

public void loginClicked(){
        String email = view.getEmail();
        String password = view.getPassword();
    if(Repository.getInstance().login(email, password))
        view.navegateToOpenActivity();
    else
        view.showError();
}

    public void onStart(){
        if(Repository.getInstance().getCurrentUser() != null){
            view.navegateToOpenActivity();
        }
        view.showError();
    }
}
