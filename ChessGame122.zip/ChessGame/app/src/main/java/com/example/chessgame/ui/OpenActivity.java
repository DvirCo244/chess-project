package com.example.chessgame.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.chessgame.R;
import com.example.chessgame.game.lobby;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Random;

public class OpenActivity extends AppCompatActivity {
    private OpenPresenter Presenter;
    private String id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_open);
        Presenter = new OpenPresenter(this);
    }

    public void logout(View view){
        Presenter.logout();
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }

    public void CreateGame(View view){
        if(Presenter.createGame())
            startActivity(new Intent(this,GameActivity.class));
    }

    public void JoinGame(View view){
        EditText GameCode = (EditText) findViewById(R.id.gameCodeJoin);
       if( Presenter.joinGame(GameCode.getText().toString())) {
           startActivity(new Intent(OpenActivity.this, GameActivity.class));
       }
    }
}