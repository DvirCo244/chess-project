package com.example.chessgame.ui;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.chessgame.R;
import com.example.chessgame.game.gameModule;

public class GameActivity extends AppCompatActivity {
private GamePresenter presenter;
private GridLayout gridLayout;
private ImageView clickedPiece;
private gameModule gameModule;
private String gameCode;
private String current_player;
private int fromRow = -1;
private int fromCol = -1;
private int toRow = -1;
private int toCol = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        presenter = new GamePresenter(this);
        setGameCode();
        gridLayout = findViewById(R.id.gridLayout);
        gameModule = new gameModule();
        }

    public void setGameCode() {
        TextView gameCodeText = findViewById(R.id.game_code);
        gameCodeText.setText("the game code is: " + presenter.getCode());
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int eventAction = event.getAction();
        int x = (int)event.getX();
        int y = (int)event.getY();
        switch (eventAction) {
            case MotionEvent.ACTION_DOWN:
                fromRow = (int) y / gridLayout.getChildAt(0).getHeight()-1;
                fromCol = (int) x / gridLayout.getChildAt(0).getWidth();
                Log.d(TAG, "down At (" + fromCol + "," + fromRow + ")");
                break;
            case MotionEvent.ACTION_UP:
                 toRow = (int) y / gridLayout.getChildAt(0).getHeight()-1;
                 toCol = (int) x / gridLayout.getChildAt(0).getWidth();
                if (gameModule.pieceAt(fromCol, fromRow) != null) {

                    if ((toRow == 7 && toCol == 4) || (toCol == 4 && toRow == 0)) {
                        startActivity(new Intent(this, OpenActivity.class));
                    }

                    clickedPiece = findViewById(gameModule.pieceAt(fromCol, fromRow).getId());
                    GridLayout.LayoutParams params = new GridLayout.LayoutParams(clickedPiece.getLayoutParams());
                    params.rowSpec = GridLayout.spec(toRow);
                    params.columnSpec = GridLayout.spec(toCol);
                    gridLayout.removeView(clickedPiece);
                    gridLayout.addView(clickedPiece, params);
                    gameModule.movePiece(fromCol, toCol, fromRow, toRow);

                    Log.d(TAG, "after move (" + gameModule.pieceAt(toCol, toRow).getCol() + "," + gameModule.pieceAt(toCol, toRow).getRow() + ")");
                }
                Log.d(TAG, "up At (" + toCol + "," + toRow + ")");
                break;
        }
        return true;
        //return super.onTouchEvent(event);
    }
}