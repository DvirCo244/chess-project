package com.example.chessgame.pieces;

import android.util.Log;

public class ChessPiece {
    private int row;
    private int col;
    private ChessPlayer player;
    private  Type pieceType;
    private int resID;
    private int id;
public enum ChessPlayer{
    WHITE,
    BLACK
}
public enum Type{
    KING,
    QUEEN,
    BISHOP,
    ROOK,
    KNIGHT,
    PAWN
}
    public ChessPiece(int row, int col, ChessPlayer player, Type type, int resID, int id){
        this.col = col;
        this.row = row;
        this.player = player;
        this.pieceType = type;
        this.resID = resID;
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    public void setRow(int row) {
        this.row = row;
    }

    public void setCol(int col) {
        this.col = col;
    }

    public int getCol() {
        return col;
    }

    public int getRow() {
        return row;
    }

    public int getResID() {
        return resID;
    }
    public String getType(){
        if(pieceType == Type.KING)
            return "KING";
        else
            if(pieceType == Type.QUEEN)
        return "QUEEN";
            else
        if(pieceType == Type.ROOK)
            return "ROOK";
        else
        if(pieceType == Type.BISHOP)
            return "BISHOP";
        else
        if(pieceType == Type.KNIGHT)
            return "KNIGHT";
        else
            return "PAWN";
    }
    public String getPlayer(){
    if(player == ChessPlayer.WHITE)
        return "WHITE";
    else
        return "BLACK";
    }

    public void printPiece() {
        String piece = "ChessPiece{" +
                "row=" + row +
                ", col=" + col +
                ", player=" + player +
                ", pieceType=" + pieceType +
                ", resID=" + resID +
                '}';
        Log.e("piece",piece);
    }
}
